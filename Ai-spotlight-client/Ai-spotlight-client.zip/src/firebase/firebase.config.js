// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCdSFltIhcje-bQYN06Xl937TkK1EhX934",
  authDomain: "ai-spotlight-58e42.firebaseapp.com",
  projectId: "ai-spotlight-58e42",
  storageBucket: "ai-spotlight-58e42.appspot.com",
  messagingSenderId: "649227974647",
  appId: "1:649227974647:web:639cc941034206cc7ce0f2",
  measurementId: "G-C1443GDJSM",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);