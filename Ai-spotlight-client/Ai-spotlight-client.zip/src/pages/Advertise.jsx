import React from 'react'

const Advertise = () => {
  return (
    <div>Advertise</div>
  )
}

export default Advertise