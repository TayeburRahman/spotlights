export const baseUrl = "https://ai-spotlight-v2.vercel.app"
// export const baseUrl = "http://localhost:6060"